//inicializar constantes de objeto XMLHTTPREQUEST
/*const READY_STATE_UNINTIALIZED = 0
const READY_STATE_LOADING = 1
const READY_STATE_LOADED = 2
const READY_STATE_INTERACTIVE = 3*/
const READY_STATE_COMPLETE = 4
let peticion_http = new XMLHttpRequest;
var opcion = 0;
var tip = '';
function cargarContenido(url, metodo, funcion) {

    peticion_http = inicializaXHR()
    if (peticion_http) {
        peticion_http.onreadystatechange = funcion
        peticion_http.open(metodo, url, true)
        peticion_http.send()
    }
}

function inicializaXHR() {
    if (window.XMLHttpRequest) {
        return new XMLHttpRequest
    } else {
        return new ActiveObject("Microsoft.XMLHTTP")
    }
}

function desocultar(obj) {
    document.getElementById('obj' + obj).style.display = 'block';
}

function mostrarMateria(numsem, suneo, objeto_json, imp, tipo) {
    desocultar(imp);
    var immateria = "";
    for (var i = 0; i < suneo.length; i++) {
        if (tipo == 'carreras') {
            var materia = objeto_json.suneo.universidades[i].carreras[i].semestre[numsem].materia;
            for (j = 0; j < materia.length; j++) {
                var mat = objeto_json.suneo.universidades[i].carreras[i].semestre[numsem].materia[j];
                immateria += mat + '<br>';
            }
        } else {
            var materia = objeto_json.suneo.universidades[i].posgrado[i].semestre[numsem].materia;
            for (j = 0; j < materia.length; j++) {
                var mat = objeto_json.suneo.universidades[i].posgrado[i].semestre[numsem].materia[j];
                immateria += mat + '<br>';
            }
        }
        if (tipo == 'carreras') {
            document.getElementById('mate' + numsem).innerHTML = immateria;
        } else {
            document.getElementById('matp' + numsem).innerHTML = immateria;
        }
    }
}

function mostrarProfesores(numsem, suneo, objeto_json, imp) {
    desocultar(imp);
    var iprofesor = "";
    for (var x = 0; x < suneo.length; x++) {
        var prof = objeto_json.suneo.universidades[x].investigadores[numsem].profesores;
        for (var j = 0; j < prof.length; j++) {
            var prof1 = objeto_json.suneo.universidades[x].investigadores[numsem].profesores[j];
            iprofesor += prof1 + '<br>';
        }
        document.getElementById('prof' + numsem).innerHTML = iprofesor;
    }
}

function fnMostrarContenido() {
    if (peticion_http.readyState == READY_STATE_COMPLETE) {
        if (peticion_http.status == 200) {
            var jsonResponse = peticion_http.responseText;
            var objeto_json = JSON.parse(jsonResponse);
            var suneo = objeto_json.suneo.universidades;
            switch (opcion) {
                case 1:
                    for (var i = 0; i < suneo.length; i++) {
                        var universidades = objeto_json.suneo.universidades[i].abreviatura;
                        document.getElementById('universidad' + i).hidden = false
                        document.getElementById('universidad' + i).value = universidades
                    }
                    break;
                case 2:
                    for (var i = 0; i < suneo.length; i++) {
                        var universidades = objeto_json.suneo.universidades[i].nombre;
                        document.getElementById('nombre' + i).hidden = false
                        document.getElementById('nombre' + i).value = universidades
                    }
                    break;
                case 3:
                    for (var i = 0; i < suneo.length; i++) {
                        var rector = objeto_json.suneo.universidades[i].rector;
                        document.getElementById('rec' + i).hidden = false
                        document.getElementById('rec' + i).value = rector
                    }
                    break;
                case 4:
                    for (var i = 0; i < suneo.length; i++) {
                        var vicea = objeto_json.suneo.universidades[i].vicea;
                        document.getElementById('vicea' + i).hidden = false
                        document.getElementById('vicea' + i).value = vicea
                    }
                    break;
                case 5:
                    for (var i = 0; i < suneo.length; i++) {
                        var vicead = objeto_json.suneo.universidades[i].vicead;
                        document.getElementById('vicead' + i).hidden = false
                        document.getElementById('vicead' + i).value = vicead
                    }
                    break;
                case 6:
                    for (var i = 0; i < suneo.length; i++) {
                        var direc = objeto_json.suneo.universidades[i].direccion;
                        document.getElementById('direc' + i).hidden = false
                        document.getElementById('direc' + i).value = direc
                    }
                    break;
                case 7:
                    for (var i = 0; i < suneo.length; i++) {
                        var car = objeto_json.suneo.universidades[i].carreras[i].nombre;
                        document.getElementById('car' + i).hidden = false
                        document.getElementById('car' + i).value = car
                    }
                    break;
                case 8:
                    desocultar(0);
                    desocultar(1);
                    desocultar(2);
                    desocultar(3);
                    desocultar(4);
                    desocultar(5);
                    for (var i = 0; i < suneo.length; i++) {
                        var dur = objeto_json.suneo.universidades[i].carreras[i].duracion;
                        document.getElementById('dur' + i).hidden = false
                        document.getElementById('dur' + i).value = dur

                        var jef = objeto_json.suneo.universidades[i].carreras[i].jefe;
                        document.getElementById('jef' + i).hidden = false
                        document.getElementById('jef' + i).value = jef

                        var est = objeto_json.suneo.universidades[i].carreras[i].activa;
                        document.getElementById('est' + i).hidden = false
                        document.getElementById('est' + i).value = est

                        var titulacion = objeto_json.suneo.universidades[i].carreras[i].titulacion;
                        for (var j = 0; j < titulacion.length; j++) {
                            var tit = objeto_json.suneo.universidades[i].carreras[i].titulacion[j];
                            document.getElementById('tit' + j).hidden = false
                            document.getElementById('tit' + j).value = tit
                        }

                        var semestre = objeto_json.suneo.universidades[i].carreras[i].semestre;
                        for (var k = 0; k < semestre.length; k++) {
                            var sem = objeto_json.suneo.universidades[i].carreras[i].semestre[k].nombre;
                            document.getElementById('sem' + k).hidden = false
                            document.getElementById('sem' + k).value = sem
                        }

                    }
                    break;
                case 9:
                    tip = 'carreras';
                    mostrarMateria(0, suneo, objeto_json, 6, tip);
                    break;
                case 10:
                    tip = 'carreras';
                    mostrarMateria(1, suneo, objeto_json, 7, tip);
                    break;
                case 11:
                    tip = 'carreras';
                    mostrarMateria(2, suneo, objeto_json, 8, tip);
                    break;
                case 12:
                    tip = 'carreras';
                    mostrarMateria(3, suneo, objeto_json, 9, tip);
                    break;
                case 13:
                    tip = 'carreras';
                    mostrarMateria(4, suneo, objeto_json, 10, tip);
                    break;
                case 14:
                    tip = 'carreras';
                    mostrarMateria(5, suneo, objeto_json, 11, tip);
                    break;
                case 15:
                    tip = 'carreras';
                    mostrarMateria(6, suneo, objeto_json, 12, tip);
                    break;
                case 16:
                    tip = 'carreras';
                    mostrarMateria(7, suneo, objeto_json, 13, tip);
                    break;
                case 17:
                    tip = 'carreras';
                    mostrarMateria(8, suneo, objeto_json, 14, tip);
                    break;
                case 18:
                    tip = 'carreras';
                    mostrarMateria(9, suneo, objeto_json, 15, tip);
                    break;
                case 19:
                    for (var i = 0; i < suneo.length; i++) {
                        var pos = objeto_json.suneo.universidades[i].posgrado[i].nombre;
                        document.getElementById('pos' + i).hidden = false
                        document.getElementById('pos' + i).value = pos
                    }
                    break;
                case 20:
                    desocultar(16);
                    desocultar(17);
                    desocultar(18);
                    desocultar(19);
                    desocultar(20);
                    desocultar(21);
                    for (var i = 0; i < suneo.length; i++) {
                        var durp = objeto_json.suneo.universidades[i].posgrado[i].duracion;
                        document.getElementById('durp' + i).hidden = false
                        document.getElementById('durp' + i).value = durp

                        var jefp = objeto_json.suneo.universidades[i].posgrado[i].jefe;
                        document.getElementById('jefp' + i).hidden = false
                        document.getElementById('jefp' + i).value = jefp

                        var estp = objeto_json.suneo.universidades[i].posgrado[i].activa;
                        document.getElementById('estp' + i).hidden = false
                        document.getElementById('estp' + i).value = estp

                        var titulacionp = objeto_json.suneo.universidades[i].posgrado[i].titulacion;
                        for (var j = 0; j < titulacionp.length; j++) {
                            var titp = objeto_json.suneo.universidades[i].posgrado[i].titulacion[j];
                            document.getElementById('titp' + j).hidden = false
                            document.getElementById('titp' + j).value = titp
                        }

                        var semestrep = objeto_json.suneo.universidades[i].posgrado[i].semestre;
                        for (var k = 0; k < semestrep.length; k++) {
                            var semp = objeto_json.suneo.universidades[i].posgrado[i].semestre[k].nombre;
                            document.getElementById('semp' + k).hidden = false
                            document.getElementById('semp' + k).value = semp
                        }
                    }
                    break;
                case 21:
                    tip = 'posgrado';
                    mostrarMateria(0, suneo, objeto_json, 22, tip);
                    break;
                case 22:
                    tip = 'posgrado';
                    mostrarMateria(1, suneo, objeto_json, 23, tip);
                    break;
                case 23:
                    tip = 'posgrado';
                    mostrarMateria(2, suneo, objeto_json, 24, tip);
                    break;
                case 24:
                    tip = 'posgrado';
                    mostrarMateria(3, suneo, objeto_json, 25, tip);
                    break;
                case 25:
                    for (var x = 0; x < suneo.length; x++) {
                        var inves = objeto_json.suneo.universidades[x].investigadores;
                        for (var j = 0; j < inves.length; j++) {
                            var nomb = objeto_json.suneo.universidades[x].investigadores[j].nombre;
                            document.getElementById('nomb' + j).hidden = false
                            document.getElementById('nomb' + j).value = nomb
                        }
                    }
                    break;
                case 26:
                    mostrarProfesores(0, suneo, objeto_json, 26);
                    break;
                case 27:
                    mostrarProfesores(1, suneo, objeto_json, 27);
                    break;
                case 28:
                    mostrarProfesores(2, suneo, objeto_json, 28);
                    break;
                case 29:
                    mostrarProfesores(3, suneo, objeto_json, 29);
                    break;
                case 30:
                    mostrarProfesores(4, suneo, objeto_json, 30);
                    break;
                case 31:
                    mostrarProfesores(5, suneo, objeto_json, 31);
                    break;
                default:
                    break;
            }
        }
    }
}

function ejemploAjax(num) {
    opcion = num;
    cargarContenido("unsis.json", "GET", fnMostrarContenido);
}

